# Management console

## Install dependencies

`npm install`

## Build for production

`npm run build`

## Usage

Run flask server

`python webapp_management_console/app.py --config webapp_management_console/development.ini`
