export function val2bool(value) {
    // convert string validation state value to boolean
    if (value === 'success')
        return true;
    return false;
}
