
export const PI_POINTS_LIST = 'PI_POINTS_LIST'

export function piPointList(list) {
    return {
        type: PI_POINTS_LIST,
        list
    }
}
