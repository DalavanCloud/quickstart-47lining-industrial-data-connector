from setuptools import setup

setup(
    name='pi2aws',
    version='1.0',
)
